Running the code: 

Method 1) 

Requirements: 

python (2.7 or 3.x) 
matplotlib 
numpy 

To run code with graphs, type this in the terminal: 
python Monte_Carlo_P1.py 

Method 2) 

Requirements: 

python (2.7 or 3.x) 
matplotlib 
numpy 
anaconda 

To run: 
1) Navigate to the folder of the file Monte_Carlo_P1.ipynb

2) Open jupyter notebook: 
jupyter notebook 

3) This will open a window in the current directory. Click/open the file Monte_Carlo_P1.ipynb

4) Click on the tab "Cell" --> "Run All" 



